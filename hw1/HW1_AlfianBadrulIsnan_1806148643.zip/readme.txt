Program VHDL dirancang oleh Alfian Badrul Isnan
NPM : 1806148643

Top-Level Entity : statistic.vhd

Panjang Bit din : 4
untuk memasukkan nilai din, diperlukan HIGH state pada go sehingga dapat tersimpan satu angka
output done menunjukkan 4 angka telah masuk dan telah dirata-ratakan.

Link Github Project : https://github.com/alfianisnan26/PSD/tree/master/hw1